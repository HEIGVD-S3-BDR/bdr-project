# Generate

This sub project contains a simple python script to generate mock data
for the database. The sql file is already generated.

## Usage

Make sure to install the dependencies in a virual environment and run:

```bash
python3 main.py > data.sql
```

## Limitations

- We do not generate yet candidats that are "Embauchés"
- We do not generate interactions yet
