from fastapi import APIRouter

router = APIRouter()

from routes import candidats, interactions, offres
